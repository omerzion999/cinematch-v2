CineMatch v2 - הנתונים לאחר המניפולציות
מגישים: תומר בלונד (322211103), עומר ציון (322757469)

catalog_post_manipulation.csv - הקטלוג הסופי: 11,013 סדרות, 22 עמודות.

מקורות (Kaggle): TMDb, IMDb top-5000, Disney+, ו-IMDb נוסף.
מניפולציות שבוצעו:
  1. מיזוג ארבעת המקורות לסכמה אחידה.
  2. הסרת כפילויות לפי שם הסדרה.
  3. נרמול מחרוזות הז'אנר וטיפול בערכים חסרים.
  4. הנדסת מאפיינים: z-scores, decade, rating_bucket, binge_fit_score.
  5. השלמת תקצירים חסרים ממקור tvs (כיסוי עלה מ-74% ל-95%).
  6. חישוב שיבוצים סמנטיים (384 ממדים) על התקצירים (קובץ נפרד embeddings.npy).

מילון נתונים (data dictionary):
  title: שם הסדרה (מפתח ייחודי)
  language: שפת המקור
  start_year: שנת תחילת השידור
  end_year: שנת סיום השידור (ריק אם עדיין משודרת)
  genres: ז'אנרים (מופרדים בפסיק)
  rating: דירוג IMDb (0-10)
  votes: מספר הצבעות
  popularity: מדד פופולריות
  overview: תקציר העלילה (הושלם ממקור tvs לסדרות שחסר בהן)
  poster_path: נתיב פוסטר ב-TMDB
  num_episodes: מספר פרקים
  num_seasons: מספר עונות
  source_dataset: מאגר המקור שממנו נלקחה הרשומה
  decade: עשור (מספרי)
  decade_str: עשור (מחרוזת, למשל 2010s)
  genre_set_str: קבוצת הז'אנרים (מופרדת ב-|) למדד Jaccard
  rating_z: ציון תקן (z-score) של הדירוג
  votes_z: ציון תקן של מספר ההצבעות
  start_year_z: ציון תקן של שנת ההתחלה
  popularity_z: ציון תקן של הפופולריות
  rating_bucket: חלוקת הדירוג לקטגוריות
  binge_fit_score: ניקוד מהונדס: (דירוג/10)*4 + הצבעות + עדכניות + שידור פעיל

קבצי ניתוח נלווים (תוצרים):
  genre_share_by_decade.csv - התפלגות ז'אנרים לפי עשור.
  rating_by_decade.csv - דירוג ו-binge_fit לפי עשור.
  genre_trend_2000s_to_2020s.csv - מגמות ז'אנר.
  genre_entropy.csv - אנטרופיית שאנון של תמהיל הז'אנרים.
  clustering_silhouette.csv - ציוני silhouette של K-Means לפי k.
  clustering_profiles.csv - פרופילי האשכולות.
  similarity_correlations.csv - מתאמי Spearman בין מדדי הדמיון.